=== The resumes ===
These resumes were provided by attendees of the 2013 Fall Tufts Hackathon. The following resumes are notable for their owners' success in the event.

James Roseman - James worked alone for this hackathon (he's a very social guy, but he showed up late), and built a scheduling interface that Tufts sorely needs, and integrated it with his already existing "Tufts Textbooks" website. We gave him first prize for his work. Ask him about it!

Brook Nichols and Ben Mesirow - These two really wowed us with their music based js-canvas game "Phantom Echoes". The representative from the EchoNest described it as very technically competent and creative. These guys coded for 24 hour straight on this one with no sleep and we awarded them first prize in the EchoNest category.

